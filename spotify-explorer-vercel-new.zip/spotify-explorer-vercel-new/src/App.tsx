import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';

// Componentes
import AuthForm from './components/auth/AuthForm';
import GenreList from './components/genres/GenreList';
import ArtistList from './components/artists/ArtistList';
import AlbumList from './components/albums/AlbumList';
import TrackList from './components/tracks/TrackList';
import TrackDetails from './components/tracks/TrackDetails';
import FilterPanel from './components/filters/FilterPanel';

// Estilos
import './App.css';

// Componente de layout principal
const Layout = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, logout } = useAuth();
  const [darkMode, setDarkMode] = useState(false);

  // Alternar modo escuro
  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
      <div className="bg-gray-100 dark:bg-gray-900 min-h-screen">
        <header className="bg-white dark:bg-gray-800 shadow">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                Spotify Explorer
              </h1>
              <div className="flex items-center space-x-4">
                <button
                  onClick={toggleDarkMode}
                  className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none"
                  aria-label="Toggle dark mode"
                >
                  {darkMode ? (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                    </svg>
                  )}
                </button>
                {isAuthenticated && (
                  <button
                    onClick={logout}
                    className="px-3 py-1 text-sm text-white bg-red-600 rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500"
                  >
                    Sair
                  </button>
                )}
              </div>
            </div>
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {children}
        </main>
        <footer className="bg-white dark:bg-gray-800 shadow mt-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <p className="text-center text-sm text-gray-500 dark:text-gray-400">
              Spotify Explorer - Desenvolvido com ❤️ - {new Date().getFullYear()}
            </p>
          </div>
        </footer>
      </div>
    </div>
  );
};

// Componente de rota protegida
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <>{children}</>;
};

// Componente principal da aplicação
const AppContent = () => {
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [selectedArtist, setSelectedArtist] = useState<any | null>(null);
  const [selectedAlbum, setSelectedAlbum] = useState<any | null>(null);
  const [selectedTrack, setSelectedTrack] = useState<any | null>(null);
  const [filters, setFilters] = useState<any>({});
  const [isFilterLoading, setIsFilterLoading] = useState(false);

  // Função para aplicar filtros
  const handleApplyFilters = (newFilters: any) => {
    setIsFilterLoading(true);
    setFilters(newFilters);
    // Simular tempo de carregamento
    setTimeout(() => {
      setIsFilterLoading(false);
    }, 500);
  };

  // Função para selecionar gênero
  const handleSelectGenre = (genre: string) => {
    setSelectedGenre(genre);
    setSelectedArtist(null);
    setSelectedAlbum(null);
    setSelectedTrack(null);
  };

  // Função para selecionar artista
  const handleSelectArtist = (artist: any) => {
    setSelectedArtist(artist);
    setSelectedAlbum(null);
    setSelectedTrack(null);
  };

  // Função para selecionar álbum
  const handleSelectAlbum = (album: any) => {
    setSelectedAlbum(album);
    setSelectedTrack(null);
  };

  // Função para selecionar música
  const handleSelectTrack = (track: any) => {
    setSelectedTrack(track);
  };

  // Função para voltar à navegação anterior
  const handleBack = () => {
    if (selectedTrack) {
      setSelectedTrack(null);
    } else if (selectedAlbum) {
      setSelectedAlbum(null);
    } else if (selectedArtist) {
      setSelectedArtist(null);
    } else if (selectedGenre) {
      setSelectedGenre(null);
    }
  };

  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/login" element={<AuthForm />} />
          <Route path="/" element={
            <ProtectedRoute>
              <div className="space-y-6">
                {/* Navegação de breadcrumb */}
                {(selectedGenre || selectedArtist || selectedAlbum || selectedTrack) && (
                  <nav className="flex" aria-label="Breadcrumb">
                    <ol className="inline-flex items-center space-x-1 md:space-x-3">
                      <li className="inline-flex items-center">
                        <button
                          onClick={() => {
                            setSelectedGenre(null);
                            setSelectedArtist(null);
                            setSelectedAlbum(null);
                            setSelectedTrack(null);
                          }}
                          className="inline-flex items-center text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-400 dark:hover:text-white"
                        >
                          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"></path>
                          </svg>
                          Início
                        </button>
                      </li>
                      {selectedGenre && (
                        <li>
                          <div className="flex items-center">
                            <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                            </svg>
                            <button
                              onClick={() => {
                                setSelectedArtist(null);
                                setSelectedAlbum(null);
                                setSelectedTrack(null);
                              }}
                              className="ml-1 text-sm font-medium text-gray-700 hover:text-green-600 md:ml-2 dark:text-gray-400 dark:hover:text-white"
                            >
                              {selectedGenre.replace(/-/g, ' ')}
                            </button>
                          </div>
                        </li>
                      )}
                      {selectedArtist && (
                        <li>
                          <div className="flex items-center">
                            <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                            </svg>
                            <button
                              onClick={() => {
                                setSelectedAlbum(null);
                                setSelectedTrack(null);
                              }}
                              className="ml-1 text-sm font-medium text-gray-700 hover:text-green-600 md:ml-2 dark:text-gray-400 dark:hover:text-white"
                            >
                              {selectedArtist.name}
                            </button>
                          </div>
                        </li>
                      )}
                      {selectedAlbum && (
                        <li>
                          <div className="flex items-center">
                            <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                            </svg>
                            <button
                              onClick={() => {
                                setSelectedTrack(null);
                              }}
                              className="ml-1 text-sm font-medium text-gray-700 hover:text-green-600 md:ml-2 dark:text-gray-400 dark:hover:text-white"
                            >
                              {selectedAlbum.name}
                            </button>
                          </div>
                        </li>
                      )}
                      {selectedTrack && (
                        <li>
                          <div className="flex items-center">
                            <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                              <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd"></path>
                            </svg>
                            <span className="ml-1 text-sm font-medium text-gray-500 md:ml-2 dark:text-gray-400">
                              {selectedTrack.name}
                            </span>
                          </div>
                        </li>
                      )}
                    </ol>
                  </nav>
                )}

                {/* Botão de voltar */}
                {(selectedGenre || selectedArtist || selectedAlbum || selectedTrack) && (
                  <button
                    onClick={handleBack}
                    className="mb-4 flex items-center text-sm font-medium text-gray-700 hover:text-green-600 dark:text-gray-400 dark:hover:text-white"
                  >
                    <svg className="w-5 h-5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                    Voltar
                  </button>
                )}

                {/* Painel de filtros (apenas para músicas) */}
                {(selectedGenre || selectedAlbum) && !selectedTrack && (
                  <FilterPanel onApplyFilters={handleApplyFilters} isLoading={isFilterLoading} />
                )}

                {/* Conteúdo principal */}
                {selectedTrack ? (
                  <TrackDetails track={selectedTrack} />
                ) : selectedAlbum ? (
                  <TrackList albumId={selectedAlbum.id} onSelectTrack={handleSelectTrack} />
                ) : selectedArtist ? (
                  <AlbumList artistId={selectedArtist.id} onSelectAlbum={handleSelectAlbum} />
                ) : selectedGenre ? (
                  <>
                    <ArtistList genreFilter={selectedGenre} onSelectArtist={handleSelectArtist} />
                    <div className="mt-8">
                      <TrackList genreFilter={selectedGenre} onSelectTrack={handleSelectTrack} />
                    </div>
                  </>
                ) : (
                  <GenreList onSelectGenre={handleSelectGenre} />
                )}
              </div>
            </ProtectedRoute>
          } />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </Router>
  );
};

// Componente raiz com provedor de autenticação
function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
