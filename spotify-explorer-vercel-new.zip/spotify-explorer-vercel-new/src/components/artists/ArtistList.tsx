import { useState, useEffect } from 'react';
import { SpotifyService } from '../../services/spotifyService';
import { useAuth } from '../../context/AuthContext';

/**
 * Interface para artista
 */
interface Artist {
  id: string;
  name: string;
  images: Array<{url: string}>;
  popularity: number;
  genres: string[];
  followers: {total: number};
}

/**
 * Componente de listagem de artistas
 */
const ArtistList = ({ 
  genreFilter, 
  onSelectArtist 
}: { 
  genreFilter?: string; 
  onSelectArtist: (artist: Artist) => void 
}) => {
  const { isAuthenticated } = useAuth();
  const [artists, setArtists] = useState<Artist[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Carregar artistas quando o filtro de gênero mudar
  useEffect(() => {
    if (isAuthenticated && genreFilter) {
      fetchArtistsByGenre(genreFilter);
    }
  }, [isAuthenticated, genreFilter]);

  // Função para buscar artistas por gênero
  const fetchArtistsByGenre = async (genre: string) => {
    setLoading(true);
    setError(null);
    
    try {
      // Usando recomendações para obter artistas relacionados ao gênero
      const data = await SpotifyService.getRecommendationsByGenre(genre);
      
      // Extrair artistas únicos das faixas
      const uniqueArtists = Array.from(
        new Map(
          data.tracks.flatMap(track => track.artists).map(artist => [artist.id, artist])
        ).values()
      );
      
      setArtists(uniqueArtists);
    } catch (err) {
      setError('Falha ao carregar artistas.');
      console.error('Erro ao buscar artistas:', err);
    } finally {
      setLoading(false);
    }
  };

  // Função para buscar artistas por termo de busca
  const searchArtists = async () => {
    if (!searchTerm.trim()) return;
    
    setLoading(true);
    setError(null);
    
    try {
      const data = await SpotifyService.searchArtists(searchTerm);
      setArtists(data.items);
    } catch (err) {
      setError('Falha ao buscar artistas.');
      console.error('Erro ao buscar artistas:', err);
    } finally {
      setLoading(false);
    }
  };

  // Lidar com envio do formulário de busca
  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    searchArtists();
  };

  // Renderizar artistas
  const renderArtists = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-40">
          <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-green-500"></div>
        </div>
      );
    }

    if (error) {
      return (
        <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded">
          {error}
        </div>
      );
    }

    if (artists.length === 0) {
      return (
        <div className="p-4 text-gray-600 dark:text-gray-400 text-center">
          Nenhum artista encontrado.
        </div>
      );
    }

    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {artists.map((artist) => (
          <div
            key={artist.id}
            onClick={() => onSelectArtist(artist)}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden cursor-pointer hover:shadow-lg transition-shadow duration-200"
          >
            <div className="h-48 bg-gray-200 dark:bg-gray-700 relative">
              {artist.images && artist.images[0] ? (
                <img
                  src={artist.images[0].url}
                  alt={artist.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-300 dark:bg-gray-700">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                  </svg>
                </div>
              )}
            </div>
            <div className="p-4">
              <h3 className="font-bold text-gray-800 dark:text-white truncate">{artist.name}</h3>
              {artist.genres && (
                <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 truncate">
                  {artist.genres.slice(0, 2).join(', ')}
                </p>
              )}
              {artist.followers && (
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                  {artist.followers.total.toLocaleString()} seguidores
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="w-full">
      <h2 className="text-xl font-bold mb-4 text-gray-800 dark:text-white">
        {genreFilter ? `Artistas: ${genreFilter.replace(/-/g, ' ')}` : 'Artistas'}
      </h2>
      
      <form onSubmit={handleSearchSubmit} className="mb-6">
        <div className="flex">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Buscar artistas..."
            className="flex-grow px-4 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-green-500"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-green-600 text-white rounded-r-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            Buscar
          </button>
        </div>
      </form>
      
      {renderArtists()}
    </div>
  );
};

export default ArtistList;
