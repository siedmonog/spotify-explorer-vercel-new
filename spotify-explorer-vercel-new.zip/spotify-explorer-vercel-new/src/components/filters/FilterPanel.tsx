import { useState } from 'react';
import { FilterOptions } from '../../services/spotifyService';

/**
 * Interface para as propriedades do componente de filtros
 */
interface FilterPanelProps {
  onApplyFilters: (filters: FilterOptions) => void;
  isLoading?: boolean;
}

/**
 * Componente de painel de filtros avançados
 */
const FilterPanel = ({ onApplyFilters, isLoading = false }: FilterPanelProps) => {
  // Estado para cada filtro
  const [minTempo, setMinTempo] = useState<number | undefined>(undefined);
  const [maxTempo, setMaxTempo] = useState<number | undefined>(undefined);
  const [minEnergy, setMinEnergy] = useState<number | undefined>(undefined);
  const [maxEnergy, setMaxEnergy] = useState<number | undefined>(undefined);
  const [minValence, setMinValence] = useState<number | undefined>(undefined);
  const [maxValence, setMaxValence] = useState<number | undefined>(undefined);
  const [minDanceability, setMinDanceability] = useState<number | undefined>(undefined);
  const [maxDanceability, setMaxDanceability] = useState<number | undefined>(undefined);
  const [minAcousticness, setMinAcousticness] = useState<number | undefined>(undefined);
  const [maxAcousticness, setMaxAcousticness] = useState<number | undefined>(undefined);
  const [minInstrumentalness, setMinInstrumentalness] = useState<number | undefined>(undefined);
  const [maxInstrumentalness, setMaxInstrumentalness] = useState<number | undefined>(undefined);
  const [minPopularity, setMinPopularity] = useState<number | undefined>(undefined);
  const [maxPopularity, setMaxPopularity] = useState<number | undefined>(undefined);
  const [minDuration, setMinDuration] = useState<number | undefined>(undefined);
  const [maxDuration, setMaxDuration] = useState<number | undefined>(undefined);
  const [isExpanded, setIsExpanded] = useState(false);

  // Função para aplicar filtros
  const handleApplyFilters = () => {
    const filters: FilterOptions = {
      ...(minTempo !== undefined && { min_tempo: minTempo }),
      ...(maxTempo !== undefined && { max_tempo: maxTempo }),
      ...(minEnergy !== undefined && { min_energy: minEnergy / 100 }),
      ...(maxEnergy !== undefined && { max_energy: maxEnergy / 100 }),
      ...(minValence !== undefined && { min_valence: minValence / 100 }),
      ...(maxValence !== undefined && { max_valence: maxValence / 100 }),
      ...(minDanceability !== undefined && { min_danceability: minDanceability / 100 }),
      ...(maxDanceability !== undefined && { max_danceability: maxDanceability / 100 }),
      ...(minAcousticness !== undefined && { min_acousticness: minAcousticness / 100 }),
      ...(maxAcousticness !== undefined && { max_acousticness: maxAcousticness / 100 }),
      ...(minInstrumentalness !== undefined && { min_instrumentalness: minInstrumentalness / 100 }),
      ...(maxInstrumentalness !== undefined && { max_instrumentalness: maxInstrumentalness / 100 }),
      ...(minPopularity !== undefined && { min_popularity: minPopularity }),
      ...(maxPopularity !== undefined && { max_popularity: maxPopularity }),
      ...(minDuration !== undefined && { min_duration_ms: minDuration * 1000 }),
      ...(maxDuration !== undefined && { max_duration_ms: maxDuration * 1000 }),
    };

    onApplyFilters(filters);
  };

  // Função para limpar todos os filtros
  const handleClearFilters = () => {
    setMinTempo(undefined);
    setMaxTempo(undefined);
    setMinEnergy(undefined);
    setMaxEnergy(undefined);
    setMinValence(undefined);
    setMaxValence(undefined);
    setMinDanceability(undefined);
    setMaxDanceability(undefined);
    setMinAcousticness(undefined);
    setMaxAcousticness(undefined);
    setMinInstrumentalness(undefined);
    setMaxInstrumentalness(undefined);
    setMinPopularity(undefined);
    setMaxPopularity(undefined);
    setMinDuration(undefined);
    setMaxDuration(undefined);
    
    onApplyFilters({});
  };

  // Renderizar controle de filtro numérico
  const renderNumberFilter = (
    label: string,
    min: number | undefined,
    max: number | undefined,
    setMin: (value: number | undefined) => void,
    setMax: (value: number | undefined) => void,
    minValue: number,
    maxValue: number,
    step: number,
    unit: string = ''
  ) => {
    return (
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          {label}
        </label>
        <div className="flex items-center space-x-2">
          <input
            type="number"
            value={min !== undefined ? min : ''}
            onChange={(e) => setMin(e.target.value ? Number(e.target.value) : undefined)}
            min={minValue}
            max={maxValue}
            step={step}
            placeholder={`Min`}
            className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
          />
          <span className="text-gray-500">-</span>
          <input
            type="number"
            value={max !== undefined ? max : ''}
            onChange={(e) => setMax(e.target.value ? Number(e.target.value) : undefined)}
            min={minValue}
            max={maxValue}
            step={step}
            placeholder={`Max`}
            className="w-full px-2 py-1 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-1 focus:ring-green-500"
          />
          {unit && <span className="text-sm text-gray-500">{unit}</span>}
        </div>
      </div>
    );
  };

  // Renderizar controle de filtro com slider
  const renderSliderFilter = (
    label: string,
    min: number | undefined,
    max: number | undefined,
    setMin: (value: number | undefined) => void,
    setMax: (value: number | undefined) => void,
    minValue: number,
    maxValue: number,
    step: number,
    unit: string = ''
  ) => {
    return (
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          {label}
        </label>
        <div className="flex items-center space-x-2 mb-1">
          <input
            type="range"
            value={min !== undefined ? min : minValue}
            onChange={(e) => setMin(Number(e.target.value))}
            min={minValue}
            max={maxValue}
            step={step}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
          />
          <span className="text-sm text-gray-500 w-10 text-right">
            {min !== undefined ? min : minValue}{unit}
          </span>
        </div>
        <div className="flex items-center space-x-2">
          <input
            type="range"
            value={max !== undefined ? max : maxValue}
            onChange={(e) => setMax(Number(e.target.value))}
            min={minValue}
            max={maxValue}
            step={step}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
          />
          <span className="text-sm text-gray-500 w-10 text-right">
            {max !== undefined ? max : maxValue}{unit}
          </span>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">
          Filtros Avançados
        </h3>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-300 focus:outline-none"
        >
          {isExpanded ? 'Recolher' : 'Expandir'}
        </button>
      </div>

      {isExpanded && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {renderNumberFilter('BPM (Tempo)', minTempo, maxTempo, setMinTempo, setMaxTempo, 40, 220, 1, ' bpm')}
          {renderSliderFilter('Energia', minEnergy, maxEnergy, setMinEnergy, setMaxEnergy, 0, 100, 1, '%')}
          {renderSliderFilter('Felicidade (Valence)', minValence, maxValence, setMinValence, setMaxValence, 0, 100, 1, '%')}
          {renderSliderFilter('Dançabilidade', minDanceability, maxDanceability, setMinDanceability, setMaxDanceability, 0, 100, 1, '%')}
          {renderSliderFilter('Acústica', minAcousticness, maxAcousticness, setMinAcousticness, setMaxAcousticness, 0, 100, 1, '%')}
          {renderSliderFilter('Instrumental', minInstrumentalness, maxInstrumentalness, setMinInstrumentalness, setMaxInstrumentalness, 0, 100, 1, '%')}
          {renderSliderFilter('Popularidade', minPopularity, maxPopularity, setMinPopularity, setMaxPopularity, 0, 100, 1, '%')}
          {renderNumberFilter('Duração (segundos)', minDuration, maxDuration, setMinDuration, setMaxDuration, 30, 600, 1, ' s')}
        </div>
      )}

      <div className="flex justify-end mt-4 space-x-2">
        <button
          onClick={handleClearFilters}
          className="px-3 py-1 text-sm text-gray-700 dark:text-gray-300 border border-gray-300 dark:border-gray-600 rounded-md hover:bg-gray-100 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-green-500"
        >
          Limpar Filtros
        </button>
        <button
          onClick={handleApplyFilters}
          disabled={isLoading}
          className={`px-3 py-1 text-sm text-white bg-green-600 rounded-md hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-green-500 ${
            isLoading ? 'opacity-70 cursor-not-allowed' : ''
          }`}
        >
          {isLoading ? 'Aplicando...' : 'Aplicar Filtros'}
        </button>
      </div>
    </div>
  );
};

export default FilterPanel;
