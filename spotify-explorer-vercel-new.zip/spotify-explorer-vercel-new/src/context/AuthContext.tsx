import { createContext, useState, useContext, ReactNode } from 'react';
import { AuthService } from '../services/authService';

// Interface para o contexto de autenticação
interface AuthContextType {
  isAuthenticated: boolean;
  token: string | null;
  clientId: string;
  clientSecret: string;
  setClientId: (id: string) => void;
  setClientSecret: (secret: string) => void;
  login: (clientId: string, clientSecret: string) => Promise<void>;
  logout: () => void;
  loading: boolean;
  error: string | null;
}

// Criando o contexto com valores padrão
const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  token: null,
  clientId: '',
  clientSecret: '',
  setClientId: () => {},
  setClientSecret: () => {},
  login: async () => {},
  logout: () => {},
  loading: false,
  error: null
});

// Props para o provedor de autenticação
interface AuthProviderProps {
  children: ReactNode;
}

// Provedor de autenticação
export const AuthProvider = ({ children }: AuthProviderProps) => {
  const [token, setToken] = useState<string | null>(AuthService.getStoredToken());
  const [clientId, setClientId] = useState<string>('');
  const [clientSecret, setClientSecret] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Verificar se está autenticado
  const isAuthenticated = !!token;

  // Função de login
  const login = async (id: string, secret: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const newToken = await AuthService.getToken(id, secret);
      AuthService.saveToken(newToken);
      setToken(newToken);
      setClientId(id);
      setClientSecret(secret);
    } catch (err) {
      setError('Falha na autenticação. Verifique suas credenciais.');
      console.error('Erro de login:', err);
    } finally {
      setLoading(false);
    }
  };

  // Função de logout
  const logout = () => {
    AuthService.clearToken();
    setToken(null);
    setClientId('');
    setClientSecret('');
  };

  // Valores do contexto
  const contextValue: AuthContextType = {
    isAuthenticated,
    token,
    clientId,
    clientSecret,
    setClientId,
    setClientSecret,
    login,
    logout,
    loading,
    error
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
};

// Hook personalizado para usar o contexto de autenticação
export const useAuth = () => useContext(AuthContext);
