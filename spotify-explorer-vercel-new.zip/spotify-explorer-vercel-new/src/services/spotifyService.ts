/**
 * Serviço para interação com a API do Spotify
 */
import axios from 'axios';
import { AuthService } from './authService';

// URL base da API (ajustar para produção/desenvolvimento)
const API_URL = 'http://localhost:3001/api';

/**
 * Interface para opções de filtro
 */
export interface FilterOptions {
  limit?: number;
  min_tempo?: number;
  max_tempo?: number;
  min_energy?: number;
  max_energy?: number;
  min_valence?: number;
  max_valence?: number;
  min_danceability?: number;
  max_danceability?: number;
  min_acousticness?: number;
  max_acousticness?: number;
  min_instrumentalness?: number;
  max_instrumentalness?: number;
  min_popularity?: number;
  max_popularity?: number;
  min_duration_ms?: number;
  max_duration_ms?: number;
}

/**
 * Classe de serviço para interação com a API
 */
export class SpotifyService {
  /**
   * Configura o cabeçalho de autorização
   * @returns Cabeçalho de autorização
   */
  private static getAuthHeader() {
    const token = AuthService.getStoredToken();
    return {
      headers: {
        Authorization: `Bearer ${token}`
      }
    };
  }

  /**
   * Obtém lista de gêneros disponíveis
   * @returns Lista de gêneros
   */
  static async getGenres() {
    try {
      const response = await axios.get(`${API_URL}/genres`, this.getAuthHeader());
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter gêneros:', error);
      throw new Error('Falha ao carregar gêneros musicais.');
    }
  }

  /**
   * Obtém recomendações baseadas em gênero
   * @param genre - Gênero musical
   * @param options - Opções de filtro
   * @returns Recomendações
   */
  static async getRecommendationsByGenre(genre: string, options: FilterOptions = {}) {
    try {
      const response = await axios.get(
        `${API_URL}/genres/${genre}/recommendations`,
        {
          ...this.getAuthHeader(),
          params: options
        }
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter recomendações:', error);
      throw new Error('Falha ao carregar recomendações.');
    }
  }

  /**
   * Busca artistas por termo
   * @param query - Termo de busca
   * @param limit - Limite de resultados
   * @returns Resultados da busca
   */
  static async searchArtists(query: string, limit: number = 20) {
    try {
      const response = await axios.get(
        `${API_URL}/artists/search`,
        {
          ...this.getAuthHeader(),
          params: { query, limit }
        }
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao buscar artistas:', error);
      throw new Error('Falha ao buscar artistas.');
    }
  }

  /**
   * Obtém artistas relacionados
   * @param artistId - ID do artista
   * @returns Artistas relacionados
   */
  static async getRelatedArtists(artistId: string) {
    try {
      const response = await axios.get(
        `${API_URL}/artists/${artistId}/related`,
        this.getAuthHeader()
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter artistas relacionados:', error);
      throw new Error('Falha ao carregar artistas relacionados.');
    }
  }

  /**
   * Obtém álbuns de um artista
   * @param artistId - ID do artista
   * @param limit - Limite de resultados
   * @returns Álbuns do artista
   */
  static async getArtistAlbums(artistId: string, limit: number = 20) {
    try {
      const response = await axios.get(
        `${API_URL}/artists/${artistId}/albums`,
        {
          ...this.getAuthHeader(),
          params: { limit }
        }
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter álbuns:', error);
      throw new Error('Falha ao carregar álbuns.');
    }
  }

  /**
   * Obtém detalhes de uma música
   * @param trackId - ID da música
   * @returns Detalhes da música
   */
  static async getTrack(trackId: string) {
    try {
      const response = await axios.get(
        `${API_URL}/tracks/${trackId}`,
        this.getAuthHeader()
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter detalhes da música:', error);
      throw new Error('Falha ao carregar detalhes da música.');
    }
  }

  /**
   * Obtém músicas de um álbum
   * @param albumId - ID do álbum
   * @returns Músicas do álbum
   */
  static async getAlbumTracks(albumId: string) {
    try {
      const response = await axios.get(
        `${API_URL}/tracks/album/${albumId}`,
        this.getAuthHeader()
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter músicas do álbum:', error);
      throw new Error('Falha ao carregar músicas do álbum.');
    }
  }

  /**
   * Obtém recomendações com filtros avançados
   * @param options - Opções de filtro
   * @returns Recomendações
   */
  static async getRecommendations(options: FilterOptions & {
    seed_genres?: string;
    seed_artists?: string;
    seed_tracks?: string;
  }) {
    try {
      const response = await axios.get(
        `${API_URL}/tracks/recommendations`,
        {
          ...this.getAuthHeader(),
          params: options
        }
      );
      return response.data.data;
    } catch (error) {
      console.error('Erro ao obter recomendações:', error);
      throw new Error('Falha ao carregar recomendações.');
    }
  }
}
